package com.example.johnschatzl_eventtracker_34;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Set the layout for this activity (Make sure activity_main.xml exists in res/layout)
        setContentView(R.layout.activity_main);

        // Example of a button that navigates to another activity (LoginActivity)
        Button btnGoToLogin = findViewById(R.id.btn_go_to_login);
        btnGoToLogin.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, LoginActivity.class);
            startActivity(intent);
        });

        // Another example to navigate to the SMS notification activity
        Button btnGoToSMS = findViewById(R.id.btn_go_to_sms);
        btnGoToSMS.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, SMSNotificationActivity.class);
            startActivity(intent);
        });

        Button btnGoToData = findViewById(R.id.btn_go_to_data);
        btnGoToData.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, DataDisplayActivity.class);
            startActivity(intent);
        });
    }
}
