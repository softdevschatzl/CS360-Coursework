package com.example.johnschatzl_eventtracker_34;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class DataDisplayActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private EventAdapter eventAdapter;
    private DatabaseHelper dbHelper;
    private EditText inputNewData;
    private Button btnAddData, btnBackToMain;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        // Initialize UI components
        recyclerView = findViewById(R.id.recycler_view_data);
        inputNewData = findViewById(R.id.input_new_data);
        btnAddData = findViewById(R.id.btn_add_data);
        btnBackToMain = findViewById(R.id.btn_back_to_main);

        dbHelper = new DatabaseHelper(this);

        // Set up RecyclerView
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        loadEvents();  // Load events from the database

        // Back to MainActivity
        btnBackToMain.setOnClickListener(view -> {
            Intent intent = new Intent(DataDisplayActivity.this, MainActivity.class);
            startActivity(intent);
            finish();  // Close current activity
        });

        // Add new event
        btnAddData.setOnClickListener(view -> {
            String eventName = inputNewData.getText().toString().trim();
            if (!eventName.isEmpty()) {
                boolean isAdded = dbHelper.addEvent(eventName, "2024-01-01", "Online", "Sample event");
                if (isAdded) {
                    Toast.makeText(this, "Event added!", Toast.LENGTH_SHORT).show();
                    inputNewData.setText("");  // Clear input field
                    loadEvents();  // Reload events
                } else {
                    Toast.makeText(this, "Failed to add event.", Toast.LENGTH_SHORT).show();
                }
            } else {
                Toast.makeText(this, "Please enter an event name.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    // Load events from the database into RecyclerView
    private void loadEvents() {
        List<Event> events = dbHelper.getAllEvents();
        if (events.isEmpty()) {
            Toast.makeText(this, "No events found.", Toast.LENGTH_SHORT).show();
        }
        eventAdapter = new EventAdapter(events, dbHelper);
        recyclerView.setAdapter(eventAdapter);
    }
}
