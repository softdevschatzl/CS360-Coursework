package com.example.johnschatzl_eventtracker_34;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EventAdapter extends RecyclerView.Adapter<EventAdapter.EventViewHolder> {

    private final List<Event> eventList;
    private final DatabaseHelper dbHelper;

    // Constructor to initialize the event list and DatabaseHelper
    public EventAdapter(List<Event> eventList, DatabaseHelper dbHelper) {
        this.eventList = eventList;
        this.dbHelper = dbHelper;
    }

    @NonNull
    @Override
    public EventViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_layout, parent, false);
        return new EventViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull EventViewHolder holder, int position) {
        Event event = eventList.get(position);

        holder.eventName.setText(event.getName());
        holder.eventDate.setText(event.getDate());
        holder.eventLocation.setText(event.getLocation());
        holder.eventDescription.setText(event.getDescription());

        // Handle delete button click
        holder.btnDeleteEvent.setOnClickListener(view -> {
            boolean isDeleted = dbHelper.deleteEvent(event.getId());
            if (isDeleted) {
                Toast.makeText(view.getContext(), "Event deleted!", Toast.LENGTH_SHORT).show();
                eventList.remove(position);  // Remove the event from the list
                notifyItemRemoved(position);  // Notify RecyclerView about the change
                notifyItemRangeChanged(position, eventList.size());  // Update the remaining items
            } else {
                Toast.makeText(view.getContext(), "Failed to delete event.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return eventList.size();
    }

    // ViewHolder class to hold item views
    public static class EventViewHolder extends RecyclerView.ViewHolder {
        TextView eventName, eventDate, eventLocation, eventDescription;
        Button btnDeleteEvent;

        public EventViewHolder(@NonNull View itemView) {
            super(itemView);
            eventName = itemView.findViewById(R.id.event_name);
            eventDate = itemView.findViewById(R.id.event_date);
            eventLocation = itemView.findViewById(R.id.event_location);
            eventDescription = itemView.findViewById(R.id.event_description);
            btnDeleteEvent = itemView.findViewById(R.id.btn_delete_event);
        }
    }
}
