package com.example.johnschatzl_eventtracker_34;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.telephony.SubscriptionInfo;
import android.telephony.SubscriptionManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import java.util.List;

public class SMSNotificationActivity extends AppCompatActivity {

    private static final int PERMISSION_REQUEST_SMS = 123;

    private Button btnCheckPermission;
    private Button btnSendSms;
    private TextView textSmsStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notifications);

        // Initialize the layout elements
        btnCheckPermission = findViewById(R.id.btn_check_sms_permission);
        btnSendSms = findViewById(R.id.btn_send_sms);
        textSmsStatus = findViewById(R.id.text_sms_status);

        // Set button click listeners
        btnCheckPermission.setOnClickListener(view -> requestSmsPermission());

        // I'm pretty sure you don't want us to actually implement SMS messaging. That'd be a lot of work.
        btnSendSms.setOnClickListener(view -> {
            String message = "Event Reminder: This is a sample SMS message";
            Toast.makeText(this, "SMS sent: " + message, Toast.LENGTH_SHORT).show();
        });

        Button btnBackToMain = findViewById(R.id.btn_back_to_main);
        btnBackToMain.setOnClickListener(view -> {
            Intent intent = new Intent(SMSNotificationActivity.this, MainActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(intent);
            finish();
        });
    }

    // Request SMS permission
    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this, new String[]{Manifest.permission.SEND_SMS}, PERMISSION_REQUEST_SMS);
        } else {
            if (!btnSendSms.isEnabled()) {
                btnSendSms.setEnabled(true);
            }
            Toast.makeText(this, "Permission already granted", Toast.LENGTH_SHORT).show();
        }
    }

    // Handle the permission result
    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == PERMISSION_REQUEST_SMS && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            textSmsStatus.setText("SMS permission granted.");
            btnSendSms.setEnabled(true);
            Toast.makeText(this, "You can now send SMS.", Toast.LENGTH_SHORT).show();
        } else if (requestCode == PERMISSION_REQUEST_SMS && grantResults.length > 0 &&
                grantResults[0] == PackageManager.PERMISSION_DENIED) {
            textSmsStatus.setText("SMS permission denied.");
            btnSendSms.setEnabled(false);
            Toast.makeText(this, "Cannot send SMS without permission.", Toast.LENGTH_SHORT).show();
        }
    }
}
